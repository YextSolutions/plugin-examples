import { getEntityData } from "./mod.ts";

Deno.test("Testing export function", async () => {
  const row = {entityId: 'insert', field: "insert", api_key: "insert"};
  const output = await getEntityData(row);
  console.log(output)
});